
import pyodbc
import os
from dotenv import load_dotenv

load_dotenv(override=True)


server   = os.getenv("SERVER")
database = os.getenv("DATABASE")
username = os.getenv("USERNAME")
password = os.getenv("PASSWORD")


conn_str = (
    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    f"SERVER={server};"
    f"DATABASE={database};"
    f"UID={username};"
    f"PWD={password}"
)


def get_connection() -> pyodbc.Connection:
 
    return pyodbc.connect(conn_str)

def get_all_users():
   
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(

            )
            for row in cursor.fetchall():
                print(row)
    except Exception as e:
        print(f"Error: {e}")


def execute_query(sql: str, params: tuple = ()):
  
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, params)
            return cursor.fetchall()
    except Exception as e:
        print(f"[execute_query] Error: {e}")
        return []


def execute_non_query(sql: str, params: tuple = ()) -> int:

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, params)
            conn.commit()
            return cursor.rowcount
    except Exception as e:
        print(f"[execute_non_query] Error: {e}")
        return -1


def execute_many(sql: str, params_list: list) -> int:

    if not params_list:
        return 0
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.fast_executemany = True
            cursor.executemany(sql, params_list)
            conn.commit()
            return len(params_list)
    except Exception as e:
        print(f"[execute_many] Error: {e}")
        return -1
