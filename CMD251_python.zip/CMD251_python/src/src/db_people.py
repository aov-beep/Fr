

from src.src_functions import execute_query, execute_non_query, execute_many
from src.src_swapi_client import Person

CREATE_TABLE_SQL = """
# IF NOT EXISTS (
#     SELECT 1 FROM sys.objects
#     WHERE object_id = OBJECT_ID(N'dbo.People') AND type = N'U'
# )
# BEGIN
#     CREATE TABLE dbo.People (
#         id            INT            PRIMARY KEY,
#         name          NVARCHAR(100)  NOT NULL,
#         height        INT            NULL,
#         mass          FLOAT          NULL,
#         hair_color    NVARCHAR(50)   NOT NULL DEFAULT 'unknown',
#         skin_color    NVARCHAR(80)   NOT NULL DEFAULT 'unknown',
#         eye_color     NVARCHAR(50)   NOT NULL DEFAULT 'unknown',
#         birth_year    NVARCHAR(20)   NOT NULL DEFAULT 'unknown',
#         gender        NVARCHAR(20)   NOT NULL DEFAULT 'unknown',
#         homeworld_id  INT            NULL,
#         created       DATETIME2      NULL,
#         edited        DATETIME2      NULL
#     );
# END
# """

INSERT_SQL = """
INSERT INTO dbo.People
    (id, name, height, mass, hair_color, skin_color,
     eye_color, birth_year, gender, homeworld_id, created, edited)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
"""

EXISTS_SQL = "SELECT 1 FROM dbo.People WHERE id = ?"

def create_people_table() -> None:
    """Створює таблицю People, якщо вона ще не існує."""
    execute_non_query(CREATE_TABLE_SQL)
    print("   [db] Таблиця People готова.")


def insert_people(people: list[Person]) -> tuple[int, int]:
 
    to_insert = []
    skipped   = 0

    for p in people:
        if execute_query(EXISTS_SQL, (p.id,)):
            skipped += 1
            continue
        to_insert.append((
            p.id, p.name, p.height, p.mass,
            p.hair_color, p.skin_color, p.eye_color,
            p.birth_year, p.gender, p.homeworld_id,
            p.created, p.edited,
        ))

    if to_insert:
        inserted = execute_many(INSERT_SQL, to_insert)
    else:
        inserted = 0

    return inserted, skipped


def get_all_people(limit: int = 100) -> list:
    
    sql = f"SELECT TOP {limit} * FROM dbo.People ORDER BY id"
    return execute_query(sql)


def get_people_by_gender(gender: str) -> list:
    
    sql = "SELECT * FROM dbo.People WHERE gender = ? ORDER BY name"
    return execute_query(sql, (gender,))


def get_top_tallest(n: int = 10) -> list:

    sql = f"""
        SELECT TOP {n} *
        FROM dbo.People
        WHERE height IS NOT NULL
        ORDER BY height DESC
    """
    return execute_query(sql)


def search_by_name(keyword: str) -> list:
   
    sql = "SELECT * FROM dbo.People WHERE name LIKE ? ORDER BY name"
    return execute_query(sql, (f"%{keyword}%",))


def get_people_by_homeworld(homeworld_id: int) -> list:
    
    sql = "SELECT * FROM dbo.People WHERE homeworld_id = ? ORDER BY name"
    return execute_query(sql, (homeworld_id,))


def get_gender_stats() -> list:
    
    sql = """
        SELECT gender, COUNT(*) AS total
        FROM dbo.People
        GROUP BY gender
        ORDER BY total DESC
    """
    return execute_query(sql)

if __name__ == "__main__":
    create_people_table()
    print("\nТоп-5 найвищих:")
    for row in get_top_tallest(5):
        print(f"  {row.name:<28} {row.height} cm")

    print("\nСтатистика по гендеру:")
    for row in get_gender_stats():
        print(f"  {row.gender:<15} {row.total}")
