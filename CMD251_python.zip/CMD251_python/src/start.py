
import os
import sys
from src.src_swapi_client import fetch_all_people
from src.db_people import create_people_table, insert_people, get_all_people, get_people_by_gender, get_top_tallest, search_by_name

def main():
    print("=" * 55)
    print("  CMD251 — Star Wars API → SQL Server")
    print("=" * 55)

   
    print("\n Перевірка / створення таблиці People ...")
    create_people_table()

    print(" Завантаження даних з https://swapi.info/api/people ...")
    people = fetch_all_people()
    print(f"      Отримано {len(people)} персонажів.")

 
    print("Запис у базу даних ...")
    inserted, skipped = insert_people(people)
    print(f"      Додано: {inserted}  |  Вже існувало: {skipped}")

 
    print("\n Демонстраційні запити")
    print("-" * 55)

    print("\n Всі персонажі (перші 10):")
    rows = get_all_people(limit=10)
    for row in rows:
        print(f"   [{row.id:>3}] {row.name:<30} | {row.gender:<14} | {row.birth_year}")

    print("\nЖінки-персонажі:")
    for row in get_people_by_gender("female"):
        print(f"   {row.name}")

    print("\n Топ-5 найвищих:")
    for row in get_top_tallest(5):
        print(f"   {row.name:<30} {row.height} cm")

    print("\n Пошук 'Skywalker':")
    for row in search_by_name("Skywalker"):
        print(f"   {row.name} ({row.birth_year})")

    print("\nГотово!")


if __name__ == "__main__":
    main()
