

import requests
from dataclasses import dataclass, field
from typing import Optional

def Get_Data(API):
    data = requests.get(API).json()
    return data
 
BASE_URL = "https://swapi.info/api"
TIMEOUT  = 15  

@dataclass
class Person:
    id:           int
    name:         str
    height:       Optional[int]
    mass:         Optional[float]
    hair_color:   str
    skin_color:   str
    eye_color:    str
    birth_year:   str
    gender:       str
    homeworld_id: Optional[int]
    created:      str
    edited:       str
def _extract_id(url: Optional[str]) -> Optional[int]:
    if not url:
        return None
    try:
        return int(url.rstrip("/").split("/")[-1])
    except ValueError:
        return None

def _to_int(value) -> Optional[int]:
    try:
        return int(float(str(value)))
    except (TypeError, ValueError):
        return None

def _to_float(value) -> Optional[float]:
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None

def _clean_str(value, default: str = "unknown") -> str:
    if value is None or str(value).strip() in ("", "n/a", "N/A", "none", "None"):
        return default
    return str(value).strip()



def fetch_all_people() -> list[Person]:

    url = f"{BASE_URL}/people"
    people: list[Person] = []

    try:
        response = requests.get(url, timeout=TIMEOUT)
        response.raise_for_status()
        data = response.json()
        if isinstance(data, list):
            items = data
        else:
            items = data.get("results", [])

        for item in items:
            person_url = item.get("url", "")
            person_id  = _extract_id(person_url)
            if person_id is None:
                continue

            person = Person(
                id           = person_id,
                name         = _clean_str(item.get("name"), "unknown"),
                height       = _to_int(item.get("height")),
                mass         = _to_float(item.get("mass")),
                hair_color   = _clean_str(item.get("hair_color")),
                skin_color   = _clean_str(item.get("skin_color")),
                eye_color    = _clean_str(item.get("eye_color")),
                birth_year   = _clean_str(item.get("birth_year")),
                gender       = _clean_str(item.get("gender")),
                homeworld_id = _extract_id(item.get("homeworld")),
                created      = str(item.get("created", "")),
                edited       = str(item.get("edited", "")),
            )
            people.append(person)

    except requests.RequestException as e:
        print(f"[swapi_client] HTTP error: {e}")
    except Exception as e:
        print(f"[swapi_client] Unexpected error: {e}")

    return people

if __name__ == "__main__":
    persons = fetch_all_people()
    print(f"Завантажено {len(persons)} персонажів\n")
    for p in persons[:5]:
        print(f"  [{p.id}] {p.name:<25} | {p.gender:<14} | {p.birth_year}")

